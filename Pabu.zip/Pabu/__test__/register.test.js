const sum = require('../public/register')

describe('prueba de inputs', () => {
    test('1+2 is 3', () => {
        sum.validarInputs(e)
    })
})